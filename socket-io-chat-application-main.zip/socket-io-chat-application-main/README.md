![image](https://github.com/MuktadirHassan/socket-io-chat-application/assets/46109431/d02774e2-3977-4bdb-9499-8fb7b39eff8e)
